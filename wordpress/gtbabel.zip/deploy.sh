#!/bin/bash

# copy venedors folder
rm -rf vendor/
cp -r ./../../vendor ./vendor/

# zip
zip -r ../gtbabel.zip .

# increase version number
# TODO

# add to subversion (or use github actions?)
# TODO