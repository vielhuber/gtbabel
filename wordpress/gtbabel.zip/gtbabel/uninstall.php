<?php

namespace _PhpScoperd1cf49dc1c15;

\delete_option('gtbabel_settings');
