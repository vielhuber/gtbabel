<?php
delete_option('gtbabel_settings');