<?php

namespace ScopedGtbabel;

\delete_option('gtbabel_settings');
