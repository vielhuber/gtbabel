<?php

namespace vielhuber\gtbabel;

class Gtbabel
{
    public $dom;
    public $utils;
    public $host;
    public $gettext;
    public $router;
    public $settings;
    public $translation;
    public $started;
    function __construct(\vielhuber\gtbabel\Dom $dom = null, \vielhuber\gtbabel\Utils $utils = null, \vielhuber\gtbabel\Host $host = null, \vielhuber\gtbabel\Gettext $gettext = null, \vielhuber\gtbabel\Router $router = null, \vielhuber\gtbabel\Settings $settings = null)
    {
        $this->settings = $settings ?: new \vielhuber\gtbabel\Settings();
        $this->utils = $utils ?: new \vielhuber\gtbabel\Utils($this->settings);
        $this->host = $host ?: new \vielhuber\gtbabel\Host($this->utils, $this->settings);
        $this->gettext = $gettext ?: new \vielhuber\gtbabel\Gettext($this->utils, $this->host, $this->settings);
        $this->dom = $dom ?: new \vielhuber\gtbabel\Dom($this->utils, $this->gettext, $this->host, $this->settings);
        $this->router = $router ?: new \vielhuber\gtbabel\Router($this->utils, $this->gettext, $this->host, $this->settings);
    }
    function start($args = [])
    {
        $this->started = \true;
        $this->settings->set($args);
        $this->host->setup();
        $this->gettext->createLngFolderIfNotExists();
        $this->gettext->preloadGettextInCache();
        if ($this->host->currentUrlIsExcluded()) {
            return;
        }
        $this->router->redirectPrefixedSourceLng();
        $this->gettext->addCurrentUrlToTranslations();
        if (!$this->host->currentUrlIsExcluded()) {
            $this->router->addTrailingSlash();
            $this->router->initMagicRouter();
        }
        \ob_start();
    }
    function stop()
    {
        if ($this->started !== \true) {
            return;
        }
        if ($this->host->currentUrlIsExcluded()) {
            return;
        }
        $content = \ob_get_contents();
        if ($this->utils->getContentType($content) === 'html') {
            $content = $this->dom->modifyHtml($content);
        } elseif ($this->utils->getContentType($content) === 'json') {
            $content = $this->dom->modifyJson($content);
        }
        \ob_end_clean();
        echo $content;
        $this->gettext->generateGettextFiles();
    }
    function reset()
    {
        $this->gettext->resetTranslations();
        $this->utils->apiStatsReset();
    }
}
